# services/formatting/formatter_service.py

"""
Deterministic structure stabiliser for NotesFlare V1.2.

This service proposes structural operations only. It does not rewrite the user's
words, correct grammar, change spelling, or title-case text. The raw Burst stays
sacred; this module emits reviewable operations for the diff pipeline.

Design goals:
- Stronger list-block detection after note headers such as "need:"
- Safer heading detection without title-casing protected/user wording
- Quote block detection for common note patterns
- Conservative paragraph breaks between existing lines
- Internal semantic splits for long one-line thought dumps
"""

from __future__ import annotations

import re
from dataclasses import dataclass

try:
    from services.formatting.parser_service import PROTECTED_TOKENS
except Exception:  # pragma: no cover - defensive fallback for unusual import paths
    PROTECTED_TOKENS = frozenset({
        "NotesFlare", "MetaMorph", "MiniLM", "Burst", "Flareon",
        "spaCy", "ONNX", "FastAPI", "SQLite",
    })


# Similarity threshold below which a paragraph break is suggested. This is now
# only one supporting signal; we no longer let embeddings alone break short listy
# or heading-like lines.
TOPIC_BREAK_THRESHOLD = 0.38

# Internal line splitting should be helpful, not noisy. Below this, leave the
# user's sentence alone unless a very explicit boundary marker exists.
MIN_STRUCTURE_WORDS = 10

_WORD_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9'’._-]*")
_SENTENCE_BOUNDARY_RE = re.compile(r"(?<=[.!?])\s+(?=[\"'“‘(\[]?[A-Za-z0-9])")
_SPACE_RE = re.compile(r"[ \t]+")
_EXPLICIT_LIST_RE = re.compile(r"^\s*([-*•])\s+|^\s*\d+[.)]\s+")

# Markers that usually begin a new thought unit in raw, unpunctuated notes.
DISCOURSE_BREAK_STARTERS = frozenset({
    "also", "another", "anyway", "besides", "but", "finally", "first",
    "however", "meanwhile", "moreover", "next", "second", "so", "still",
    "then", "therefore", "third", "though", "yet",
})

SOFT_BREAK_STARTERS = frozenset({
    "maybe", "perhaps", "probably", "possibly",
})

CLAUSE_VERBS = frozenset({
    "am", "is", "are", "was", "were", "be", "been", "being",
    "become", "becomes", "became", "carry", "carries", "depend", "depends",
    "discuss", "discusses", "explain", "explains", "feel", "feels", "has",
    "have", "had", "improve", "improves", "make", "makes", "need", "needs",
    "reveal", "reveals", "shift", "shifts", "happen", "happens", "work",
    "works", "cost", "costs", "support", "supports", "weaken", "weakens",
})

SUBORDINATORS = frozenset({
    "because", "that", "which", "who", "when", "while", "where", "if", "although",
    "since", "after", "before", "until", "unless",
})

PRONOUN_SUBJECTS = frozenset({
    "i", "you", "he", "she", "it", "we", "they", "this", "that", "these", "those",
    "itself", "myself", "yourself", "himself", "herself", "ourselves", "themselves",
})

TOPIC_SHIFT_STARTERS = frozenset({
    "another", "however", "meanwhile", "moreover", "therefore", "next", "second",
    "third", "finally", "but", "also",
})

LIST_HEADER_WORDS = frozenset({
    "need", "needs", "todo", "todos", "tasks", "ideas", "points", "questions",
    "issues", "problems", "steps", "features", "include", "includes", "requirements",
    "check", "checks", "remember", "focus", "plan", "plans", "try", "tries",
})

HEADING_HINT_ENDINGS = (
    "thoughts", "notes", "plan", "architecture", "design", "roadmap", "summary",
    "questions", "problems", "issues", "idea", "ideas", "review", "lesson", "class",
)

QUOTE_PATTERNS = (
    re.compile(r"^\s*quote\s+(from|:)\b", re.IGNORECASE),
    re.compile(r"^\s*(my\s+)?(supervisor|teacher|professor|client|manager)\s+said\b", re.IGNORECASE),
    re.compile(r"^\s*(said|according\s+to|as\s+said|quoted)\b", re.IGNORECASE),
)

Operation = dict[str, str | int]


@dataclass(frozen=True)
class LineContext:
    in_implicit_list: bool
    follows_heading: bool
    follows_blank: bool
    previous_non_empty_index: int | None


def generate_operations(
    line_signals: list[dict],
    similarity_scores: list[float] | None = None,
) -> list[dict]:
    """
    Given parser signals and optional line-to-line similarity scores, return
    deterministic formatting operations.
    """
    operations: list[dict] = []
    contexts = _build_contexts(line_signals)

    for i, signal in enumerate(line_signals):
        line = signal["text"]
        stripped = line.strip()
        context = contexts[i]

        if not signal.get("token_count"):
            continue

        # Never touch tiny protected-token-only lines such as "NotesFlare".
        if signal.get("contains_protected_token") and signal.get("token_count", 0) <= 2:
            continue

        # 1) Explicit or implicit list items must win over heading detection.
        if signal.get("is_list_item_candidate"):
            formatted = _format_explicit_list_item(line)
            if formatted != line:
                operations.append(_op(i, "format_as_list_item", line, formatted))
            continue

        if context.in_implicit_list:
            formatted = _format_implicit_list_item(line)
            if formatted != line:
                operations.append(_op(i, "format_as_list_item", line, formatted))
            continue

        # 2) Heading detection is structural only. No title-casing. No word edits.
        if _should_format_as_heading(i, signal, line, line_signals, contexts):
            formatted = _format_heading(line)
            if formatted != line:
                operations.append(_op(i, "format_as_heading", line, formatted))
            continue

        # 3) Quote detection uses common raw-note wording.
        if signal.get("is_quote_candidate") or _is_quote_like(line):
            formatted = _format_quote(line)
            if formatted != line:
                operations.append(_op(i, "format_as_quote", line, formatted))
            continue

        # 4) Internal one-line stabilisation.
        structured = _format_semantic_structure(line)
        needs_topic_prefix = _should_prefix_topic_break(i, signal, line, line_signals, contexts, similarity_scores)
        if structured != line:
            if needs_topic_prefix and not structured.startswith("\n"):
                structured = "\n" + structured
            operations.append(_op(i, "insert_line_break", line, structured))
            continue

        # 5) Paragraph break between existing lines.
        if needs_topic_prefix:
            operations.append(_op(i, "insert_paragraph_break", line, "\n" + line))

    return operations


def _op(line_index: int, operation: str, raw_before: str, formatted_after: str) -> dict:
    return {
        "line_index": line_index,
        "operation": operation,
        "raw_before": raw_before,
        "formatted_after": formatted_after,
    }


def _build_contexts(line_signals: list[dict]) -> list[LineContext]:
    contexts: list[LineContext] = []
    active_list_header_index: int | None = None
    previous_non_empty_index: int | None = None
    previous_was_headingish = False

    for i, signal in enumerate(line_signals):
        text = signal.get("text", "")
        stripped = text.strip()
        follows_blank = i > 0 and line_signals[i - 1].get("token_count", 0) == 0

        if not stripped:
            contexts.append(LineContext(False, False, follows_blank, previous_non_empty_index))
            active_list_header_index = None
            previous_was_headingish = False
            continue

        # A colon/list header opens an implicit list context for following short lines.
        if _is_list_header(stripped):
            contexts.append(LineContext(False, previous_was_headingish, follows_blank, previous_non_empty_index))
            active_list_header_index = i
            previous_non_empty_index = i
            previous_was_headingish = False
            continue

        in_implicit_list = False
        if active_list_header_index is not None:
            in_implicit_list = _can_be_implicit_list_item(stripped)
            if not in_implicit_list:
                active_list_header_index = None

        contexts.append(LineContext(in_implicit_list, previous_was_headingish, follows_blank, previous_non_empty_index))

        previous_was_headingish = _is_headingish_without_formatting(signal, stripped) and not in_implicit_list
        previous_non_empty_index = i

    return contexts


def _is_list_header(stripped: str) -> bool:
    if not stripped.endswith(":"):
        return False
    words = [_clean_word(w) for w in _WORD_RE.findall(stripped[:-1])]
    if not words:
        return False
    if len(words) <= 3 and words[0] in LIST_HEADER_WORDS:
        return True
    return len(words) <= 2


def _can_be_implicit_list_item(stripped: str) -> bool:
    if not stripped:
        return False
    if stripped.endswith((".", "?", "!")):
        return False
    if _is_list_header(stripped):
        return False
    if _is_quote_like(stripped):
        return False
    words = _WORD_RE.findall(stripped)
    return 1 <= len(words) <= 9


def _format_explicit_list_item(line: str) -> str:
    leading = line[: len(line) - len(line.lstrip())]
    stripped = line.strip()
    if stripped.startswith("- "):
        return leading + stripped
    bullet = re.match(r"^[*•]\s+(.*)$", stripped)
    if bullet:
        return leading + "- " + bullet.group(1)
    numbered = re.match(r"^\d+[.)]\s+", stripped)
    if numbered:
        return leading + stripped
    return line


def _format_implicit_list_item(line: str) -> str:
    leading = line[: len(line) - len(line.lstrip())]
    stripped = line.strip()
    if stripped.startswith("- "):
        return leading + stripped
    return f"{leading}- {stripped}"


def _should_format_as_heading(
    i: int,
    signal: dict,
    line: str,
    line_signals: list[dict],
    contexts: list[LineContext],
) -> bool:
    stripped = line.strip()
    if not _is_headingish_without_formatting(signal, stripped):
        return False

    context = contexts[i]
    if context.in_implicit_list:
        return False
    if context.previous_non_empty_index is not None:
        prev_text = line_signals[context.previous_non_empty_index].get("text", "").strip()
        if _is_list_header(prev_text):
            return False

    # Avoid turning every short phrase into a visible heading. Prefer clear note
    # headers: first lines, lines after blanks, or lines followed by denser text.
    next_non_empty = _next_non_empty_signal(i, line_signals)
    follows_blank_or_start = i == 0 or context.follows_blank
    followed_by_content = bool(next_non_empty and next_non_empty.get("token_count", 0) >= 6)
    has_heading_hint = _first_word(stripped) in {"chapter", "lesson", "section", "topic"} or stripped.lower().endswith(HEADING_HINT_ENDINGS)

    return has_heading_hint and (follows_blank_or_start or followed_by_content)


def _is_headingish_without_formatting(signal: dict, stripped: str) -> bool:
    if not signal.get("is_heading_candidate"):
        return False
    if stripped.startswith(("#", ">", "- ")):
        return False
    if _EXPLICIT_LIST_RE.match(stripped):
        return False
    # Protected names may appear inside headings; they are allowed because we do
    # not alter casing anymore.
    return True


def _format_heading(line: str) -> str:
    """Add a structural heading marker without changing the user's words."""
    leading = line[: len(line) - len(line.lstrip())]
    stripped = line.strip()
    if stripped.startswith("## "):
        return leading + stripped
    return f"{leading}## {stripped}"


def _is_quote_like(line: str) -> bool:
    stripped = line.strip()
    if stripped.startswith((">", "\"", "'", "“", "‘")):
        return True
    return any(pattern.search(stripped) for pattern in QUOTE_PATTERNS)


def _format_quote(line: str) -> str:
    """Add a quote marker without changing quote text."""
    leading = line[: len(line) - len(line.lstrip())]
    stripped = line.strip()
    if stripped.startswith("> "):
        return leading + stripped
    if stripped.startswith('"') and stripped.endswith('"'):
        # Keep the quote words unchanged except structural blockquote marker.
        return f"{leading}> {stripped}"
    return f"{leading}> {stripped}"


def _format_semantic_structure(line: str) -> str:
    """
    Propose internal line breaks for a raw thought line.

    Deterministic and conservative:
    1. Sentence punctuation can become line breaks for long dumps.
    2. Explicit discourse markers can start a new thought block.
    3. A second independent clause can split when a new subject+verb pattern
       appears far enough into the line.
    """
    stripped = line.strip()
    if not stripped:
        return line

    leading = line[: len(line) - len(line.lstrip())]
    trailing = line[len(line.rstrip()):]
    compact = _SPACE_RE.sub(" ", stripped)

    # Do not internally split structural lines that should be handled elsewhere.
    if _is_list_header(compact) or _EXPLICIT_LIST_RE.match(compact) or _is_quote_like(compact):
        return f"{leading}{compact}{trailing}" if compact != stripped else line

    sentence_units = _split_sentences(compact)
    if len(sentence_units) >= 2:
        structured = _join_sentence_units(sentence_units)
        return f"{leading}{structured}{trailing}"

    words = _word_spans(compact)
    break_positions = _find_unpunctuated_break_positions(compact, words)
    if len(words) < MIN_STRUCTURE_WORDS and not break_positions:
        return f"{leading}{compact}{trailing}" if compact != stripped else line

    if not break_positions:
        return f"{leading}{compact}{trailing}" if compact != stripped else line

    structured = _apply_break_positions(compact, break_positions)
    return f"{leading}{structured}{trailing}"


def _split_sentences(text: str) -> list[str]:
    parts = [p.strip() for p in _SENTENCE_BOUNDARY_RE.split(text) if p.strip()]
    if len(parts) == 2 and len(_WORD_RE.findall(text)) < 28:
        second_first = _first_word(parts[1])
        if second_first not in TOPIC_SHIFT_STARTERS:
            return [text]
    return parts


def _join_sentence_units(sentences: list[str]) -> str:
    if len(sentences) <= 1:
        return sentences[0] if sentences else ""

    lines: list[str] = []
    current_block: list[str] = []

    for idx, sentence in enumerate(sentences):
        first = _first_word(sentence)
        starts_shift = first in TOPIC_SHIFT_STARTERS or _starts_named_concept(sentence)

        if idx > 0 and (starts_shift or _should_start_new_sentence_block(current_block, sentence)):
            if current_block:
                lines.append("\n".join(current_block))
                current_block = []
        current_block.append(sentence)

    if current_block:
        lines.append("\n".join(current_block))

    return "\n\n".join(lines)


def _should_start_new_sentence_block(current_block: list[str], next_sentence: str) -> bool:
    if not current_block:
        return False
    current_words = sum(len(_WORD_RE.findall(s)) for s in current_block)
    next_words = len(_WORD_RE.findall(next_sentence))

    if len(current_block) >= 3:
        return True
    if current_words >= 42:
        return True
    if current_words <= 8 and next_words >= 12:
        return True
    return False


def _find_unpunctuated_break_positions(text: str, words: list[tuple[str, int, int]]) -> list[int]:
    breaks: list[int] = []
    lowered = [_clean_word(w[0]) for w in words]

    for i, word in enumerate(lowered):
        if i < 3:
            continue

        previous_word = lowered[i - 1]
        next_word = lowered[i + 1] if i + 1 < len(lowered) else ""

        if word in DISCOURSE_BREAK_STARTERS or word in SOFT_BREAK_STARTERS:
            if i >= 3 and _enough_words_since_last_break(i, words, breaks, min_words=3):
                breaks.append(words[i][1])
            continue

        phrase3 = " ".join(lowered[i:i + 3])
        phrase2 = " ".join(lowered[i:i + 2])
        if phrase3 == "on the other" or phrase2 in {"in contrast", "as a"}:
            if _enough_words_since_last_break(i, words, breaks):
                breaks.append(words[i][1])
            continue

        if (
            next_word in CLAUSE_VERBS
            and _has_previous_clause(lowered[:i])
            and previous_word not in SUBORDINATORS
            and word not in SUBORDINATORS
            and word not in PRONOUN_SUBJECTS
            and _looks_like_new_clause_subject(word)
            and not _looks_like_compound_term(previous_word, word)
            and _enough_words_since_last_break(i, words, breaks)
        ):
            breaks.append(words[i][1])

    return _dedupe_close_breaks(breaks)


def _looks_like_new_clause_subject(word: str) -> bool:
    # Keep subject+verb splitting conservative. This catches examples like
    # "... meaning embeddings become ..." but avoids splitting compound terms
    # such as "ablation study depends ...".
    if word.endswith("s") and len(word) > 3:
        return True
    return word in {
        "embedding", "embeddings", "latency", "retrieval", "formatting",
        "chunking", "storage", "pipeline", "structure", "model", "system",
    }


def _looks_like_compound_term(previous_word: str, word: str) -> bool:
    return (previous_word, word) in {
        ("ablation", "study"),
        ("semantic", "search"),
        ("paper", "structure"),
        ("method", "section"),
        ("dataset", "bias"),
        ("literature", "review"),
        ("citation", "mapping"),
        ("annotation", "quality"),
        ("boundary", "quality"),
        ("model", "comparison"),
        ("review", "comments"),
        ("query", "drift"),
        ("embedding", "cache"),
        ("evidence", "chain"),
        ("false", "positives"),
        ("raw", "note"),
    }


def _word_spans(text: str) -> list[tuple[str, int, int]]:
    return [(m.group(0), m.start(), m.end()) for m in _WORD_RE.finditer(text)]


def _has_previous_clause(words: list[str]) -> bool:
    return any(w in CLAUSE_VERBS or w.endswith(("ing", "ed")) for w in words)


def _enough_words_since_last_break(
    word_index: int,
    words: list[tuple[str, int, int]],
    breaks: list[int],
    min_words: int = 4,
) -> bool:
    if not breaks:
        return word_index >= min_words

    last_char = breaks[-1]
    words_after_last = sum(1 for _, start, _ in words[:word_index] if start > last_char)
    return words_after_last >= min_words


def _dedupe_close_breaks(breaks: list[int]) -> list[int]:
    deduped: list[int] = []
    for pos in sorted(set(breaks)):
        if not deduped or pos - deduped[-1] > 16:
            deduped.append(pos)
    return deduped


def _apply_break_positions(text: str, breaks: list[int]) -> str:
    parts: list[str] = []
    last = 0
    for pos in breaks:
        parts.append(text[last:pos].strip())
        last = pos
    parts.append(text[last:].strip())
    return "\n\n".join(part for part in parts if part)


def _should_prefix_topic_break(
    i: int,
    signal: dict,
    line: str,
    line_signals: list[dict],
    contexts: list[LineContext],
    similarity_scores: list[float] | None,
) -> bool:
    if i <= 0:
        return False

    context = contexts[i]
    if context.follows_blank or context.in_implicit_list:
        return False

    previous_index = context.previous_non_empty_index
    if previous_index is None:
        return False

    previous_signal = line_signals[previous_index]
    previous_text = previous_signal.get("text", "").strip()
    stripped = line.strip()

    if _is_list_header(previous_text):
        return False
    if _can_be_implicit_list_item(stripped) and _can_be_implicit_list_item(previous_text):
        return False

    first = _first_word(stripped)
    if first in TOPIC_SHIFT_STARTERS:
        return True

    if signal.get("has_conjunction_start") and previous_signal.get("token_count", 0) > 12:
        return True

    if similarity_scores and i - 1 < len(similarity_scores):
        score = similarity_scores[i - 1]
        prev_tokens = previous_signal.get("token_count", 0)
        this_tokens = signal.get("token_count", 0)
        # Embedding distance is useful, but in the old benchmark it caused short
        # list-like fragments to be separated randomly. Require enough content.
        if score < TOPIC_BREAK_THRESHOLD and prev_tokens >= 6 and this_tokens >= 6:
            return True

    # Put a blank line after a heading marker when followed by content.
    if previous_text.startswith("## ") or _should_format_as_heading(previous_index, previous_signal, previous_text, line_signals, contexts):
        return signal.get("token_count", 0) >= 4

    return False


def _next_non_empty_signal(i: int, line_signals: list[dict]) -> dict | None:
    for j in range(i + 1, len(line_signals)):
        if line_signals[j].get("token_count", 0) > 0:
            return line_signals[j]
    return None


def _first_word(text: str) -> str:
    match = _WORD_RE.search(text.strip())
    return _clean_word(match.group(0)) if match else ""


def _clean_word(word: str) -> str:
    return word.strip("'’\".,;:!?()[]{}<> ").lower()


def _starts_named_concept(sentence: str) -> bool:
    stripped = sentence.strip()
    if not stripped:
        return False
    first_word = _WORD_RE.search(stripped)
    if not first_word:
        return False
    token = first_word.group(0)
    return token[:1].isupper() and token not in {"I", "The", "A", "An", "This", "That", "It"}

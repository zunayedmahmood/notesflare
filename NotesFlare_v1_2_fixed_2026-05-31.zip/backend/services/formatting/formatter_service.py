# services/formatting/formatter_service.py

"""
Rule-driven structural formatter for NotesFlare V1.2.

This formatter is:
- Rule-based (no LLM, no generative model)
- Structural only (paragraph breaks, lists, headings, quotes)
- Non-destructive toward protected product/system tokens
- Operation-emitting (returns operations, not rewritten text)

Input:  list of line signals from parser_service
Output: list of formatting operations
"""

from __future__ import annotations

import re

try:
    from services.formatting.parser_service import PROTECTED_TOKENS
except Exception:  # pragma: no cover - defensive fallback for unusual import paths
    PROTECTED_TOKENS = frozenset({
        "NotesFlare", "MetaMorph", "MiniLM", "Burst", "Flareon",
        "spaCy", "ONNX", "FastAPI", "SQLite",
    })


# Minimum token count before a line qualifies for heading detection
HEADING_MAX_TOKENS = 7

# Similarity threshold below which a paragraph break is suggested
TOPIC_BREAK_THRESHOLD = 0.45


def generate_operations(
    line_signals: list[dict],
    similarity_scores: list[float] | None = None,
) -> list[dict]:
    """
    Given NLP line signals (from parser_service) and optional similarity scores
    (from embedding_service), return a list of formatting operations.

    Each operation dict:
    {
        "line_index": int,
        "operation": str,
        "raw_before": str,
        "formatted_after": str,
    }
    """
    operations = []

    for i, signal in enumerate(line_signals):
        line = signal["text"]

        # Skip empty lines
        if not signal["token_count"]:
            continue

        # ── List item formatting ──────────────────────────────────────────────
        # List normalization is structural and does not change the words.
        if signal["is_list_item_candidate"]:
            formatted = _format_list_item(line)
            if formatted != line:
                operations.append({
                    "line_index": i,
                    "operation": "format_as_list_item",
                    "raw_before": line,
                    "formatted_after": formatted,
                })
            continue

        # ── Heading formatting ────────────────────────────────────────────────
        # Preserve protected tokens exactly (NotesFlare must not become Notesflare).
        if signal["is_heading_candidate"] and signal["token_count"] <= HEADING_MAX_TOKENS:
            formatted = _format_heading(line)
            if formatted != line:
                operations.append({
                    "line_index": i,
                    "operation": "format_as_heading",
                    "raw_before": line,
                    "formatted_after": formatted,
                })
            continue

        # ── Quote formatting ──────────────────────────────────────────────────
        if signal["is_quote_candidate"]:
            formatted = _format_quote(line)
            if formatted != line:
                operations.append({
                    "line_index": i,
                    "operation": "format_as_quote",
                    "raw_before": line,
                    "formatted_after": formatted,
                })
            continue

        # ── Paragraph break insertion ─────────────────────────────────────────
        # Insert a paragraph break BEFORE this line if:
        # (a) embedding similarity with previous non-empty line is below threshold
        # (b) or the line starts with a discourse conjunction after a long line
        if similarity_scores and i > 0 and i - 1 < len(similarity_scores):
            if similarity_scores[i - 1] < TOPIC_BREAK_THRESHOLD:
                operations.append({
                    "line_index": i,
                    "operation": "insert_paragraph_break",
                    "raw_before": line,
                    "formatted_after": "\n" + line,
                })
                continue

        if signal["has_conjunction_start"] and i > 0:
            prev = line_signals[i - 1]
            if prev["token_count"] > 12:
                operations.append({
                    "line_index": i,
                    "operation": "insert_paragraph_break",
                    "raw_before": line,
                    "formatted_after": "\n" + line,
                })

    return operations


def _format_list_item(line: str) -> str:
    """Normalize list item: ensure bullet is "- " prefix where applicable."""
    stripped = line.strip()
    if stripped.startswith("- "):
        return stripped
    if re.match(r"^[*•]\s", stripped):
        return "- " + stripped[2:]
    if re.match(r"^\d+[.)]\s", stripped):
        return stripped
    return line


def _format_heading(line: str) -> str:
    """Title-case a heading candidate while preserving protected tokens exactly."""
    stripped = line.strip()
    titled = stripped.title() if not (stripped == stripped.upper() and len(stripped) > 2) else stripped.title()
    return _restore_protected_tokens(stripped, titled)


def _restore_protected_tokens(original: str, formatted: str) -> str:
    """Restore exact protected token casing after safe structural formatting."""
    restored = formatted
    for token in sorted(PROTECTED_TOKENS, key=len, reverse=True):
        pattern = re.compile(rf"(?<!\w){re.escape(token)}(?!\w)", re.IGNORECASE)
        # Only restore if the token was present in the original line.
        if re.search(rf"(?<!\w){re.escape(token)}(?!\w)", original):
            restored = pattern.sub(token, restored)
    return restored


def _format_quote(line: str) -> str:
    """Ensure a straight double-quoted line uses typographic quote chars."""
    stripped = line.strip()
    if stripped.startswith('"') and stripped.endswith('"'):
        return "\u201c" + stripped[1:-1] + "\u201d"
    return stripped

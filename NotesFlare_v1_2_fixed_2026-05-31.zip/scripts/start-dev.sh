#!/usr/bin/env bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
cd "$PROJECT_ROOT"

if [ -d ".venv" ]; then
  PYTHON="$PROJECT_ROOT/.venv/bin/python"
else
  PYTHON=$(which python3 2>/dev/null || which python 2>/dev/null)
fi

if [ -z "$PYTHON" ]; then
  echo "✗ Python not found. Run scripts/install.sh first."
  exit 1
fi

cleanup() {
  echo ""
  echo "→ Shutting down NotesFlare..."
  if [ -n "${ELECTRON_PID:-}" ]; then kill "$ELECTRON_PID" 2>/dev/null || true; fi
  if [ -n "${FRONTEND_PID:-}" ]; then kill "$FRONTEND_PID" 2>/dev/null || true; fi
  if [ -n "${BACKEND_PID:-}" ]; then kill "$BACKEND_PID" 2>/dev/null || true; fi
  echo "✓ Stopped."
  exit 0
}
trap cleanup EXIT INT TERM

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  NotesFlare — Starting Dev Environment"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

echo "→ Checking V1.2 optional NLP dependencies..."
$PYTHON - <<'PY' || true
missing = []
try:
    import spacy
    try:
        spacy.load('en_core_web_sm')
    except OSError:
        missing.append('spaCy en_core_web_sm model (parser will use fallback heuristics)')
except ImportError:
    missing.append('spaCy (parser will use fallback heuristics if spaCy is installed later)')
try:
    import sentence_transformers  # noqa: F401
except ImportError:
    missing.append('sentence-transformers (semantic similarity will be skipped)')
try:
    import onnxruntime  # noqa: F401
except ImportError:
    missing.append('onnxruntime (accelerator unavailable)')

if missing:
    print('  Optional NLP items missing:')
    for item in missing:
        print('   - ' + item)
    print('  NotesFlare will still run; install full requirements for the complete NLP path.')
else:
    print('  Full NLP stack available.')
PY
echo ""

echo "→ Starting Python backend on port 8000..."
cd "$PROJECT_ROOT/backend"
$PYTHON main.py &
BACKEND_PID=$!
cd "$PROJECT_ROOT"
echo "  Backend PID: $BACKEND_PID"

echo "→ Waiting for backend..."
for i in {1..40}; do
  if curl -s http://127.0.0.1:8000/api/health > /dev/null 2>&1; then
    echo "✓ Backend is ready."
    break
  fi
  sleep 0.25
  if [ "$i" = "40" ]; then
    echo "✗ Backend did not start. Check logs above."
    exit 1
  fi
done

echo "→ Starting Next.js frontend on port 3000..."
NEXT_TELEMETRY_DISABLED=1 npm run dev:frontend &
FRONTEND_PID=$!
echo "  Frontend PID: $FRONTEND_PID"

echo "→ Waiting for frontend..."
for i in {1..80}; do
  if curl -s http://127.0.0.1:3000 > /dev/null 2>&1; then
    echo "✓ Frontend is ready."
    break
  fi
  sleep 0.25
  if [ "$i" = "80" ]; then
    echo "✗ Frontend did not start. Check logs above."
    exit 1
  fi
done

echo "→ Compiling Electron TypeScript..."
npm run build:electron
echo "✓ Electron compiled."

echo "→ Launching Electron..."
NODE_ENV=development npx electron . &
ELECTRON_PID=$!
wait "$ELECTRON_PID"
